<?php
print_r($_GET);
	$group=[
	['name'=>'Koyte Winemiller', 'class'=> 'ASE230', 'grade'=>'Senior'&Alpha],
	['name'=>'Josh', 'class'=> 'ASE230', 'grade'=>'Senior'&Alpha],
	['name'=>'Nick', 'class'=> 'ASE230', 'grade'=>'Senior'&Alpha],
	];
	
print_r($group[$_GET['id']]);
?>

<h1><?= $group[$_GET['id']]['name']?></h1>
<h1><?= $_GET['name']?></h1>
 
<div>
				<a class="text-muted">
				<i class= "fab fa-file"></i> echo <a href="localhost/page.php">?>Me</a>
				</div>
