	<!doctype html>
	
	<?php
print_r($_GET);
	$group=[
	['name'=>'Koyte Winemiller', 'class'=> 'ASE230', 'grade'=>'Senior&#8704;'],
	['name'=>'Josh', 'class'=> 'ASE230', 'grade'=>'Senior&forall;'],
	['name'=>'Nick', 'class'=> 'ASE230', 'grade'=>'Senior&forall;'],
	];
	
	$i=0;
	foreach ($group as $member) {
		echo '<h1>'.$member['name'].'</h1>';
		echo '<a href="detail.php?grade='.$i.
		'&name='.$member['class'].'">View details</a>';
		$i++;
		}
?>

	<html lang="en">
		<!-- https://www.bootdey.com/snippets/view/team-user-resume#html -->
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css" integrity="sha256-mmgLkCYLUQbXn0B1SRqzHar6dCnv9oZFPEC1g1cwlkk=" crossorigin="anonymous" />		
			<link rel="stylesheet" href="assets/css/detail.css" />
			
		<body>
			<title><?php echo 'This is ASE 230 - Koyte Winemiller' ?></title>
			
			<div class="container text-center mb-5">
				<h1><?php echo 'This is ASE 230 - Koyte Winemiller' ?></h1>

				
			</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-5 col-md-6"></div>
				<div class="mb-2">
				<img class= "w-100" src="KOYTE_WINEMILLER.jpg" alt="Image of Me">
				</div>
				<div class="mb-2 d-flex">
				<h4 class="font-weight-normal"><?php 'Koyte Winemiller' ?></h4>
			  
				<div class="social d-flex ml-auto"></div>
				<p class="pr-2 font-weight-normal"><?php 'Follow on:' ?></p>
				<a href="#" class="text-muted mr-1">
				  <i class="fab fa-facebook-f"></i><a href="https://www.facebook.com/koyte.winemiller/">Koyte Winemiller
				  
				</a>
				<a href="#" class="text-muted mr-1">
				  <i class="fab fa-twitter"></i> echo <a href="https://twitter.com/koyte_w">Koyte Winemiller
				  
				</a>
				<a href="#" class="text-muted mr-1">
				  <i class="fab fa-instagram"></i><a href="https://www.instagram.com/s1lent_stranger/">Koyte Winemiller
				  
				</a>
				<a href="#" class="text-muted">
				  <i class="fab fa-linkedin"></i><a href="https://www.linkedin.com/in/koyte-winemiller-103398173/">Koyte Winemiller
				</a>
				
				
				<a href="#" class="text-muted">
				<i class= "fab fa-outlook"></i><a href="localhost/detail.php">Me
				</a>
				
				
			  </div>
			</div>
			<div class="mb-2">
			  <ul class="list-unstyled">
				<li class="media">
				  <span class="w-25 text-black font-weight-normal"><?php 'Dream profession: ' ?></span>
				  <label class="media-body"><?php 'Web Application Analyst' ?></label>
				  
				</li>
				<li class="media">
				  <span class="w-25 text-black font-weight-normal"><?php 'Dream company: ' ?></span>
				  <label class="media-body"><?php 'Any IT company' ?>
				  </label>
				  
				</li>
				<li class="media">
				  <span class="w-25 text-black font-weight-normal"><?php 'Email: ' ?></span>
				  
				  <label class="media-body"><a href="https://outlook.office.com/mail/WINEMILLEK1@mymail.nku.edu">WINEMILLEK1@mymail.nku.edu</a></label>
				</li>
			  </ul>
			</div>
		  </div>
		  <div class="col-lg-7 col-md-6 pl-xl-3">
			<h5 class="font-weight-normal"><?php echo 'Short intro' ?></h5>
			
			<p><?php echo 'Hello, My name is Koyte (pronounced Cody but with a t) Winemiller, I am a undergraduate Senior working on my CIT (Computer Information Technology) Major. I am currently in my final year at NKU and I am actively seeking an internship to help jump start my career after NKU. ' ?></p>
			
			<div class="my-2 bg-light p-2">
			  <p class="font-italic mb-0"><?php echo 'Do what you can, with what you have, where you are.- Theodore Roosevelt' ?></p>
			</div>
			<div class="mb-2 mt-2 pt-1">
			  <h5 class="font-weight-normal"><?php echo 'Information Technology' ?></h5>
			</div>
			<div class="py-1">
			  <div class="progress">
			  
				<div class="progress-bar" role="progressbar" style="width:85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">
				  <div class="progress-bar-title"><?php echo 'HTML' ?><span class="progress-bar-number"><?php echo ' 85%' ?></span></div>
				</div>
			  </div>
			</div>
			<div class="py-1">
			  <div class="progress">
			  
				<div class="progress-bar" role="progressbar" style="width:70%" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">
				  <div class="progress-bar-title"><?php echo 'Cyber Security' ?><span class="progress-bar-number"><?php echo ' 70%' ?></span></div>
				</div>
			  </div>
			</div>
			<div class="py-1">
			  <div class="progress">
			  
				<div class="progress-bar" role="progressbar" style="width:77%" aria-valuenow="77" aria-valuemin="0" aria-valuemax="100">
				  <div class="progress-bar-title"><?php echo 'Python' ?><span class="progress-bar-number"><?php echo ' 77%' ?></span></div>
				  
				</div>
			  </div>
			</div>
			<h5 class="font-weight-normal"><?php echo 'Fun fact' ?></h5>
			
			<p><?php echo 'My name came from changing up Coyote.'  ?></p>
			</div>
		</div>
	  </div>
		<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>